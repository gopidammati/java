This Project is a java based web application.  
We can use maven to build this project.  
In this project, we have created a Jenkinsfile, which can be used in a pipeline or multibranch pipeline job
